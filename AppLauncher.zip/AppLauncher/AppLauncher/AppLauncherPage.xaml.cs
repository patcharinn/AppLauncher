﻿using Xamarin.Forms;

namespace AppLauncher
{
	public partial class AppLauncherPage : ContentPage
	{
		public AppLauncherPage()
		{
			InitializeComponent();
		}
	}
}
